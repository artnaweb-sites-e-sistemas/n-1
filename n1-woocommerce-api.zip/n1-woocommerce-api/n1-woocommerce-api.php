<?php
/**
 * Plugin Name: N-1 WooCommerce API
 * Plugin URI: https://loja.n-1edicoes.org
 * Description: API REST customizada para integração do template React/Next.js com WooCommerce
 * Version: 1.0.0
 * Author: N-1 Edições
 * Author URI: https://loja.n-1edicoes.org
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: n1-woocommerce-api
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Handler de erros para garantir que sempre retornemos JSON
add_action('rest_api_init', function() {
    // Garantir que erros sejam retornados como JSON
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=UTF-8');
    }
}, 1);

class N1_WooCommerce_API {
    
    private $namespace = 'n1/v1';
    private $stripe_secret_key = 'sk_test_51SpZZiR0R7yHOSAazG9L81muQRM7HdTT2LcjRGl6RpBohC65L4Wv3uDEqWdmgMqc2gYdRW3ol7X3TsTlyomVv2TH006iGbXYj1';
    
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
        add_action('rest_api_init', array($this, 'add_cors_support'));
        
        // Capturar erros fatais
        register_shutdown_function(array($this, 'handle_fatal_error'));
    }
    
    /**
     * Handle fatal errors and return JSON instead of HTML
     */
    public function handle_fatal_error() {
        $error = error_get_last();
        if ($error !== NULL && in_array($error['type'], array(E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_PARSE))) {
            // Se estamos em uma requisição REST API, retornar JSON
            if (defined('REST_REQUEST') && REST_REQUEST) {
                header('Content-Type: application/json; charset=UTF-8');
                http_response_code(500);
                echo json_encode(array(
                    'code' => 'fatal_error',
                    'message' => 'Erro fatal no servidor',
                    'data' => array('status' => 500)
                ));
                exit;
            }
        }
    }
    
    /**
     * Register REST API routes
     */
    public function register_routes() {
        // Get all products
        register_rest_route($this->namespace, '/products', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_products'),
            'permission_callback' => '__return_true',
        ));
        
        // Get single product
        register_rest_route($this->namespace, '/products/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_product'),
            'permission_callback' => '__return_true',
        ));
        
        // Get single product with /api/ prefix (for template compatibility)
        register_rest_route($this->namespace, '/api/products/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_product'),
            'permission_callback' => '__return_true',
        ));
        
        // Get featured products
        register_rest_route($this->namespace, '/products/show', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_featured_products'),
            'permission_callback' => '__return_true',
        ));
        
        // Get featured products with /api/ prefix (for template compatibility)
        register_rest_route($this->namespace, '/api/products/show', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_featured_products'),
            'permission_callback' => '__return_true',
        ));
        
        // Get discount products
        register_rest_route($this->namespace, '/products/discount', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_discount_products'),
            'permission_callback' => '__return_true',
        ));
        
        // Get discount products with /api/ prefix (for template compatibility)
        register_rest_route($this->namespace, '/api/products/discount', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_discount_products'),
            'permission_callback' => '__return_true',
        ));
        
        // Get related products
        register_rest_route($this->namespace, '/products/relatedProduct', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_related_products'),
            'permission_callback' => '__return_true',
            'args' => array(
                'tags' => array(
                    'required' => false,
                    'type' => 'string',
                ),
            ),
        ));
        
        // Get related products with /api/ prefix (for template compatibility)
        register_rest_route($this->namespace, '/api/products/relatedProduct', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_related_products'),
            'permission_callback' => '__return_true',
            'args' => array(
                'tags' => array(
                    'required' => false,
                    'type' => 'string',
                ),
            ),
        ));
        
        // Get categories
        register_rest_route($this->namespace, '/categories', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_categories'),
            'permission_callback' => '__return_true',
        ));
        
        // Get categories (alias for template compatibility)
        register_rest_route($this->namespace, '/category/show', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_categories'),
            'permission_callback' => '__return_true',
        ));
        
        // Get categories with /api/ prefix (for template compatibility)
        register_rest_route($this->namespace, '/api/category/show', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_categories'),
            'permission_callback' => '__return_true',
        ));
        
        // Get coupons
        register_rest_route($this->namespace, '/coupon', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_coupons'),
            'permission_callback' => '__return_true',
        ));
        
        // Get coupons with /api/ prefix (for template compatibility)
        register_rest_route($this->namespace, '/api/coupon', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_coupons'),
            'permission_callback' => '__return_true',
        ));
        
        // Get products/show with /api/ prefix (for template compatibility)
        register_rest_route($this->namespace, '/api/products/show', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_featured_products'),
            'permission_callback' => '__return_true',
        ));
        
        // Search products
        register_rest_route($this->namespace, '/products/search', array(
            'methods' => 'GET',
            'callback' => array($this, 'search_products'),
            'permission_callback' => '__return_true',
            'args' => array(
                'q' => array(
                    'required' => true,
                    'type' => 'string',
                ),
            ),
        ));
        
        // User Authentication Routes
        // Register user
        register_rest_route($this->namespace, '/api/user/signup', array(
            'methods' => 'POST',
            'callback' => array($this, 'register_user'),
            'permission_callback' => '__return_true',
        ));
        
        // Login user
        register_rest_route($this->namespace, '/api/user/login', array(
            'methods' => 'POST',
            'callback' => array($this, 'login_user'),
            'permission_callback' => '__return_true',
        ));
        
        // Get current user
        register_rest_route($this->namespace, '/api/user/me', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_current_user'),
            'permission_callback' => array($this, 'check_authentication'),
        ));
        
        // Forgot password
        register_rest_route($this->namespace, '/api/user/forget-password', array(
            'methods' => 'PATCH',
            'callback' => array($this, 'forgot_password'),
            'permission_callback' => '__return_true',
        ));
        
        // Confirm forgot password
        register_rest_route($this->namespace, '/api/user/confirm-forget-password', array(
            'methods' => 'PATCH',
            'callback' => array($this, 'confirm_forgot_password'),
            'permission_callback' => '__return_true',
        ));
        
        // Change password
        register_rest_route($this->namespace, '/api/user/change-password', array(
            'methods' => 'PATCH',
            'callback' => array($this, 'change_password'),
            'permission_callback' => array($this, 'check_authentication'),
        ));
        
        // Update user profile
        register_rest_route($this->namespace, '/api/user/update-user/(?P<id>\d+)', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_user'),
            'permission_callback' => array($this, 'check_authentication'),
        ));
        
        // Confirm email
        register_rest_route($this->namespace, '/api/user/confirmEmail/(?P<token>[a-zA-Z0-9]+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'confirm_email'),
            'permission_callback' => '__return_true',
        ));
        
        // Create Payment Intent (Stripe)
        register_rest_route($this->namespace, '/api/order/create-payment-intent', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_payment_intent'),
            'permission_callback' => array($this, 'check_authentication'),
        ));
        
        // Add Order (WooCommerce)
        register_rest_route($this->namespace, '/api/order/addOrder', array(
            'methods' => 'POST',
            'callback' => array($this, 'add_order'),
            'permission_callback' => array($this, 'check_authentication'),
        ));
        
        // Get all orders by user
        register_rest_route($this->namespace, '/api/user-order/order-by-user', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_user_orders'),
            'permission_callback' => array($this, 'check_authentication'),
        ));
        
        // Get single order by ID
        register_rest_route($this->namespace, '/api/user-order/single-order/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_single_order'),
            'permission_callback' => array($this, 'check_authentication'),
        ));
    }
    
    /**
     * Add CORS support
     */
    public function add_cors_support() {
        // Aplicar CORS antes de qualquer processamento
        add_action('rest_api_init', function() {
            header('Access-Control-Allow-Credentials: true');
        }, 15);
        
        remove_filter('rest_pre_serve_request', 'rest_send_cors_headers');
        add_filter('rest_pre_serve_request', function($value) {
            // Lista de origens permitidas
            $allowed_origins = array(
                'https://n-1.artnaweb.com.br',
                'http://n-1.artnaweb.com.br',
                'https://loja.n-1edicoes.org',
                'http://loja.n-1edicoes.org',
                'http://localhost:3000',
                'http://localhost:3001',
            );
            
            // Obter origem da requisição
            $origin = '';
            if (isset($_SERVER['HTTP_ORIGIN'])) {
                $origin = $_SERVER['HTTP_ORIGIN'];
            } elseif (isset($_SERVER['HTTP_REFERER'])) {
                $parsed = parse_url($_SERVER['HTTP_REFERER']);
                $origin = $parsed['scheme'] . '://' . $parsed['host'];
                if (isset($parsed['port'])) {
                    $origin .= ':' . $parsed['port'];
                }
            }
            
            // Se a origem está na lista de permitidas, usar ela; senão usar wildcard
            if (!empty($origin) && in_array($origin, $allowed_origins)) {
                header('Access-Control-Allow-Origin: ' . $origin);
            } else {
                header('Access-Control-Allow-Origin: *');
            }
            
            header('Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE, PATCH');
            header('Access-Control-Allow-Credentials: true');
            header('Access-Control-Allow-Headers: Authorization, Content-Type, X-Requested-With, Accept');
            
            // Responder a requisições OPTIONS (preflight)
            if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
                http_response_code(200);
                exit;
            }
            
            return $value;
        }, 10);
        
        // Garantir CORS mesmo em erros
        add_filter('rest_pre_dispatch', function($result, $server, $request) {
            $allowed_origins = array(
                'https://n-1.artnaweb.com.br',
                'http://n-1.artnaweb.com.br',
                'https://loja.n-1edicoes.org',
                'http://loja.n-1edicoes.org',
                'http://localhost:3000',
                'http://localhost:3001',
            );
            
            $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
            if (!empty($origin) && in_array($origin, $allowed_origins)) {
                header('Access-Control-Allow-Origin: ' . $origin);
            } else {
                header('Access-Control-Allow-Origin: *');
            }
            
            header('Access-Control-Allow-Credentials: true');
            header('Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE, PATCH');
            header('Access-Control-Allow-Headers: Authorization, Content-Type, X-Requested-With, Accept');
            
            return $result;
        }, 10, 3);
    }
    
    /**
     * Format product data for API response
     */
    private function format_product($product) {
        if (!$product || !is_a($product, 'WC_Product')) {
            return null;
        }
        
        $product_id = $product->get_id();
        $image_id = $product->get_image_id();
        $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'large') : wc_placeholder_img_src();
        
        $regular_price = floatval($product->get_regular_price());
        $sale_price = $product->get_sale_price() ? floatval($product->get_sale_price()) : $regular_price;
        $discount = 0;
        
        if ($regular_price > 0 && $sale_price < $regular_price) {
            $discount = round((($regular_price - $sale_price) / $regular_price) * 100);
        }
        
        // Get product tags
        $tags = wp_get_post_terms($product_id, 'product_tag', array('fields' => 'names'));
        
        // Get product categories
        $categories = wp_get_post_terms($product_id, 'product_cat', array('fields' => 'names'));
        
        // Determine itemInfo (top-rated, best-selling, latest-product)
        $item_info = 'latest-product';
        if ($product->is_featured()) {
            $item_info = 'top-rated';
        }
        
        // Check if best selling (you can customize this logic)
        $total_sales = $product->get_total_sales();
        if ($total_sales > 10) {
            $item_info = 'best-selling';
        }
        
        return array(
            '_id' => (string)$product_id,
            'id' => $product_id,
            'title' => $product->get_name(),
            'description' => $product->get_description(),
            'shortDescription' => $product->get_short_description(),
            'image' => $image_url,
            'images' => $this->get_product_images($product),
            'price' => $sale_price,
            'originalPrice' => $regular_price,
            'discount' => $discount,
            'sku' => $product->get_sku(),
            'stock' => $product->get_stock_quantity(),
            'inStock' => $product->is_in_stock(),
            'tags' => $tags,
            'categories' => $categories,
            'itemInfo' => $item_info,
            'rating' => array(
                'average' => $product->get_average_rating(),
                'count' => $product->get_rating_count(),
            ),
            'permalink' => get_permalink($product_id),
        );
    }
    
    /**
     * Get product images
     */
    private function get_product_images($product) {
        $images = array();
        $image_ids = $product->get_gallery_image_ids();
        
        // Add main image
        $main_image_id = $product->get_image_id();
        if ($main_image_id) {
            $images[] = wp_get_attachment_image_url($main_image_id, 'large');
        }
        
        // Add gallery images
        foreach ($image_ids as $image_id) {
            $images[] = wp_get_attachment_image_url($image_id, 'large');
        }
        
        return $images;
    }
    
    /**
     * Get all products
     */
    public function get_products($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce não está ativo', array('status' => 500));
        }
        
        $params = $request->get_query_params();
        $per_page = isset($params['per_page']) ? intval($params['per_page']) : 12;
        $page = isset($params['page']) ? intval($params['page']) : 1;
        $category = isset($params['category']) ? sanitize_text_field($params['category']) : '';
        $orderby = isset($params['orderby']) ? sanitize_text_field($params['orderby']) : 'date';
        $order = isset($params['order']) ? sanitize_text_field($params['order']) : 'DESC';
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => $per_page,
            'paged' => $page,
            'post_status' => 'publish',
            'orderby' => $orderby,
            'order' => $order,
        );
        
        if (!empty($category)) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'slug',
                    'terms' => $category,
                ),
            );
        }
        
        $query = new WP_Query($args);
        $products = array();
        
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $product = wc_get_product(get_the_ID());
                $formatted = $this->format_product($product);
                if ($formatted) {
                    $products[] = $formatted;
                }
            }
            wp_reset_postdata();
        }
        
        return rest_ensure_response(array(
            'products' => $products,
            'total' => $query->found_posts,
            'pages' => $query->max_num_pages,
            'current_page' => $page,
        ));
    }
    
    /**
     * Get single product
     */
    public function get_product($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce não está ativo', array('status' => 500));
        }
        
        $product_id = intval($request['id']);
        $product = wc_get_product($product_id);
        
        if (!$product) {
            return new WP_Error('product_not_found', 'Produto não encontrado', array('status' => 404));
        }
        
        $formatted = $this->format_product($product);
        
        if (!$formatted) {
            return new WP_Error('product_error', 'Erro ao formatar produto', array('status' => 500));
        }
        
        return rest_ensure_response($formatted);
    }
    
    /**
     * Get featured products
     * Retorna produtos em destaque, ou todos os produtos se não houver destaque
     */
    public function get_featured_products($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce não está ativo', array('status' => 500));
        }
        
        // Primeiro, tenta buscar produtos em destaque usando a taxonomia moderna do WooCommerce
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_visibility',
                    'field' => 'name',
                    'terms' => 'featured',
                ),
            ),
        );
        
        $query = new WP_Query($args);
        $products = array();
        
        // Se não encontrou produtos em destaque, busca todos os produtos publicados
        if (!$query->have_posts()) {
            $args = array(
                'post_type' => 'product',
                'posts_per_page' => -1,
                'post_status' => 'publish',
            );
            $query = new WP_Query($args);
        }
        
        // Alternativa: busca usando meta_query (método antigo)
        if (!$query->have_posts()) {
            $args = array(
                'post_type' => 'product',
                'posts_per_page' => -1,
                'post_status' => 'publish',
                'meta_query' => array(
                    array(
                        'key' => '_featured',
                        'value' => 'yes',
                    ),
                ),
            );
            $query = new WP_Query($args);
        }
        
        // Se ainda não encontrou, retorna todos os produtos publicados
        if (!$query->have_posts()) {
            $args = array(
                'post_type' => 'product',
                'posts_per_page' => 12, // Limita a 12 produtos
                'post_status' => 'publish',
                'orderby' => 'date',
                'order' => 'DESC',
            );
            $query = new WP_Query($args);
        }
        
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $product = wc_get_product(get_the_ID());
                $formatted = $this->format_product($product);
                if ($formatted) {
                    $products[] = $formatted;
                }
            }
            wp_reset_postdata();
        }
        
        return rest_ensure_response(array('products' => $products));
    }
    
    /**
     * Get discount products
     */
    public function get_discount_products($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce não está ativo', array('status' => 500));
        }
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'meta_query' => array(
                array(
                    'key' => '_sale_price',
                    'value' => '',
                    'compare' => '!=',
                ),
            ),
        );
        
        $query = new WP_Query($args);
        $products = array();
        
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $product = wc_get_product(get_the_ID());
                $formatted = $this->format_product($product);
                if ($formatted && $formatted['discount'] > 0) {
                    $products[] = $formatted;
                }
            }
            wp_reset_postdata();
        }
        
        return rest_ensure_response(array('products' => $products));
    }
    
    /**
     * Get related products
     */
    public function get_related_products($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce não está ativo', array('status' => 500));
        }
        
        $tags = isset($request['tags']) ? explode(',', $request['tags']) : array();
        
        if (empty($tags)) {
            return rest_ensure_response(array('products' => array()));
        }
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 4,
            'post_status' => 'publish',
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_tag',
                    'field' => 'name',
                    'terms' => $tags,
                ),
            ),
        );
        
        $query = new WP_Query($args);
        $products = array();
        
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $product = wc_get_product(get_the_ID());
                $formatted = $this->format_product($product);
                if ($formatted) {
                    $products[] = $formatted;
                }
            }
            wp_reset_postdata();
        }
        
        return rest_ensure_response(array('products' => $products));
    }
    
    /**
     * Get categories
     */
    public function get_categories($request) {
        $terms = get_terms(array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
        ));
        
        $categories = array();
        
        if (!is_wp_error($terms) && !empty($terms)) {
            foreach ($terms as $term) {
                $categories[] = array(
                    '_id' => (string)$term->term_id,
                    'id' => $term->term_id,
                    'name' => $term->name,
                    'slug' => $term->slug,
                    'count' => $term->count,
                );
            }
        }
        
        // Return format compatible with template
        // Template expects either 'categories' or direct array
        return rest_ensure_response(array('categories' => $categories));
    }
    
    /**
     * Search products
     */
    public function search_products($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce não está ativo', array('status' => 500));
        }
        
        $search_term = sanitize_text_field($request['q']);
        
        if (empty($search_term)) {
            return rest_ensure_response(array('products' => array()));
        }
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 20,
            'post_status' => 'publish',
            's' => $search_term,
        );
        
        $query = new WP_Query($args);
        $products = array();
        
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $product = wc_get_product(get_the_ID());
                $formatted = $this->format_product($product);
                if ($formatted) {
                    $products[] = $formatted;
                }
            }
            wp_reset_postdata();
        }
        
        return rest_ensure_response(array('products' => $products));
    }
    
    /**
     * Get coupons
     */
    public function get_coupons($request) {
        if (!class_exists('WooCommerce')) {
            return rest_ensure_response(array('coupons' => array()));
        }
        
        // Get active coupons from WooCommerce
        $args = array(
            'post_type' => 'shop_coupon',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'meta_query' => array(
                array(
                    'key' => 'expiry_date',
                    'value' => date('Y-m-d'),
                    'compare' => '>=',
                ),
            ),
        );
        
        $query = new WP_Query($args);
        $coupons = array();
        
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $coupon_id = get_the_ID();
                $coupon = new WC_Coupon($coupon_id);
                
                if ($coupon->is_valid()) {
                    $coupons[] = array(
                        '_id' => (string)$coupon_id,
                        'id' => $coupon_id,
                        'code' => $coupon->get_code(),
                        'amount' => floatval($coupon->get_amount()),
                        'discountType' => $coupon->get_discount_type(),
                        'description' => $coupon->get_description(),
                        'expiryDate' => $coupon->get_date_expires() ? $coupon->get_date_expires()->date('Y-m-d') : null,
                    );
                }
            }
            wp_reset_postdata();
        }
        
        return rest_ensure_response(array('coupons' => $coupons));
    }
    
    /**
     * Check authentication
     */
    public function check_authentication() {
        try {
            error_log('N1 API - check_authentication: Iniciando verificação');
            
            // Função compatível para obter headers
            $headers = array();
            if (function_exists('getallheaders')) {
                $headers = getallheaders();
            } else {
                foreach ($_SERVER as $name => $value) {
                    if (substr($name, 0, 5) == 'HTTP_') {
                        $header_name = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))));
                        $headers[$header_name] = $value;
                    }
                }
            }
            
            error_log('N1 API - check_authentication: Headers obtidos: ' . print_r(array_keys($headers), true));
            
            $auth_header = '';
            if (isset($headers['Authorization'])) {
                $auth_header = $headers['Authorization'];
            } elseif (isset($headers['authorization'])) {
                $auth_header = $headers['authorization'];
            } elseif (isset($_SERVER['HTTP_AUTHORIZATION'])) {
                $auth_header = $_SERVER['HTTP_AUTHORIZATION'];
            } elseif (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
                $auth_header = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
            }
            
            if (empty($auth_header)) {
                error_log('N1 API - check_authentication: Token não fornecido');
                return new WP_Error('unauthorized', 'Token de autenticação não fornecido', array('status' => 401));
            }
            
            error_log('N1 API - check_authentication: Header Authorization encontrado');
            
            // Extract token from "Bearer {token}"
            if (preg_match('/Bearer\s+(.*)$/i', $auth_header, $matches)) {
                $token = trim($matches[1]);
                error_log('N1 API - check_authentication: Token extraído (primeiros 10 caracteres): ' . substr($token, 0, 10));
                
                $user_id = $this->validate_token($token);
                if ($user_id) {
                    error_log('N1 API - check_authentication: Token válido para usuário ID: ' . $user_id);
                    wp_set_current_user($user_id);
                    // Garantir que o usuário está definido globalmente
                    global $wp_current_user;
                    $wp_current_user = get_userdata($user_id);
                    return true;
                } else {
                    error_log('N1 API - check_authentication: Token inválido ou não encontrado');
                }
            } else {
                error_log('N1 API - check_authentication: Formato do header Authorization inválido');
            }
            
            return new WP_Error('unauthorized', 'Token de autenticação inválido', array('status' => 401));
        } catch (Exception $e) {
            error_log('N1 API - check_authentication: Exceção: ' . $e->getMessage());
            error_log('N1 API - check_authentication: Stack trace: ' . $e->getTraceAsString());
            return new WP_Error('auth_error', 'Erro ao verificar autenticação: ' . $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Validate token and return user ID
     */
    private function validate_token($token) {
        // Check if token exists in user meta
        $users = get_users(array(
            'meta_key' => 'n1_api_token',
            'meta_value' => $token,
            'number' => 1,
        ));
        
        if (!empty($users)) {
            $user = $users[0];
            // Check if token is not expired (optional: add expiry check)
            return $user->ID;
        }
        
        return false;
    }
    
    /**
     * Generate API token for user
     */
    private function generate_token($user_id) {
        $token = wp_generate_password(32, false);
        update_user_meta($user_id, 'n1_api_token', $token);
        return $token;
    }
    
    /**
     * Format user data for API response
     */
    private function format_user($user) {
        if (!$user || !is_a($user, 'WP_User')) {
            return null;
        }
        
        return array(
            '_id' => (string)$user->ID,
            'id' => $user->ID,
            'name' => $user->display_name,
            'email' => $user->user_email,
            'role' => !empty($user->roles) ? $user->roles[0] : 'customer',
        );
    }
    
    /**
     * Register new user
     */
    public function register_user($request) {
        $params = $request->get_json_params();
        
        $name = isset($params['name']) ? sanitize_text_field($params['name']) : '';
        $email = isset($params['email']) ? sanitize_email($params['email']) : '';
        $password = isset($params['password']) ? $params['password'] : '';
        $confirm_password = isset($params['confirmPassword']) ? $params['confirmPassword'] : '';
        
        // Validation
        if (empty($name) || empty($email) || empty($password)) {
            return new WP_Error('missing_fields', 'Nome, e-mail e senha são obrigatórios', array('status' => 400));
        }
        
        if (!is_email($email)) {
            return new WP_Error('invalid_email', 'E-mail inválido', array('status' => 400));
        }
        
        if (strlen($password) < 6) {
            return new WP_Error('weak_password', 'A senha deve ter pelo menos 6 caracteres', array('status' => 400));
        }
        
        if ($password !== $confirm_password) {
            return new WP_Error('password_mismatch', 'As senhas não coincidem', array('status' => 400));
        }
        
        // Check if user already exists
        if (email_exists($email)) {
            return new WP_Error('email_exists', 'Este e-mail já está cadastrado', array('status' => 409));
        }
        
        // Create user
        $user_id = wp_create_user($email, $password, $email);
        
        if (is_wp_error($user_id)) {
            return new WP_Error('registration_failed', $user_id->get_error_message(), array('status' => 500));
        }
        
        // Update user display name
        wp_update_user(array(
            'ID' => $user_id,
            'display_name' => $name,
        ));
        
        // Set user role as customer (WooCommerce)
        $user = new WP_User($user_id);
        $user->set_role('customer');
        
        // Generate token
        $token = $this->generate_token($user_id);
        
        // Get formatted user data
        $user_data = $this->format_user($user);
        
        return rest_ensure_response(array(
            'message' => 'Usuário cadastrado com sucesso',
            'data' => array(
                'user' => $user_data,
                'token' => $token,
            ),
        ));
    }
    
    /**
     * Login user
     */
    public function login_user($request) {
        $params = $request->get_json_params();
        
        $email = isset($params['email']) ? sanitize_email($params['email']) : '';
        $password = isset($params['password']) ? $params['password'] : '';
        
        // Validation
        if (empty($email) || empty($password)) {
            return new WP_Error('missing_fields', 'E-mail e senha são obrigatórios', array('status' => 400));
        }
        
        // Authenticate user
        $user = wp_authenticate($email, $password);
        
        if (is_wp_error($user)) {
            return new WP_Error('invalid_credentials', 'E-mail ou senha inválidos', array('status' => 401));
        }
        
        // Generate token
        $token = $this->generate_token($user->ID);
        
        // Get formatted user data
        $user_data = $this->format_user($user);
        
        return rest_ensure_response(array(
            'message' => 'Login realizado com sucesso',
            'data' => array(
                'user' => $user_data,
                'token' => $token,
            ),
        ));
    }
    
    /**
     * Get current user
     */
    public function get_current_user($request) {
        $current_user_id = get_current_user_id();
        
        if (!$current_user_id) {
            return new WP_Error('not_authenticated', 'Usuário não autenticado', array('status' => 401));
        }
        
        $user = get_userdata($current_user_id);
        $user_data = $this->format_user($user);
        
        return rest_ensure_response($user_data);
    }
    
    /**
     * Forgot password
     */
    public function forgot_password($request) {
        $params = $request->get_json_params();
        
        $email = isset($params['email']) ? sanitize_email($params['email']) : '';
        
        if (empty($email)) {
            return new WP_Error('missing_email', 'E-mail é obrigatório', array('status' => 400));
        }
        
        $user = get_user_by('email', $email);
        
        if (!$user) {
            // Don't reveal if email exists for security
            return rest_ensure_response(array(
                'message' => 'Se o e-mail existir, você receberá um link para redefinir sua senha',
            ));
        }
        
        // Generate reset token
        $reset_token = wp_generate_password(32, false);
        update_user_meta($user->ID, 'n1_reset_token', $reset_token);
        update_user_meta($user->ID, 'n1_reset_token_expiry', time() + 3600); // 1 hour
        
        // In a real implementation, send email with reset link
        // For now, just return success message
        
        return rest_ensure_response(array(
            'message' => 'Se o e-mail existir, você receberá um link para redefinir sua senha',
            'token' => $reset_token, // Remove this in production, only for testing
        ));
    }
    
    /**
     * Confirm forgot password
     */
    public function confirm_forgot_password($request) {
        $params = $request->get_json_params();
        
        $token = isset($params['token']) ? sanitize_text_field($params['token']) : '';
        $new_password = isset($params['password']) ? $params['password'] : '';
        
        if (empty($token) || empty($new_password)) {
            return new WP_Error('missing_fields', 'Token e nova senha são obrigatórios', array('status' => 400));
        }
        
        // Find user by reset token
        $users = get_users(array(
            'meta_key' => 'n1_reset_token',
            'meta_value' => $token,
            'number' => 1,
        ));
        
        if (empty($users)) {
            return new WP_Error('invalid_token', 'Token inválido ou expirado', array('status' => 400));
        }
        
        $user = $users[0];
        
        // Check if token is expired
        $expiry = get_user_meta($user->ID, 'n1_reset_token_expiry', true);
        if ($expiry && time() > $expiry) {
            delete_user_meta($user->ID, 'n1_reset_token');
            delete_user_meta($user->ID, 'n1_reset_token_expiry');
            return new WP_Error('expired_token', 'Token expirado', array('status' => 400));
        }
        
        // Update password
        wp_set_password($new_password, $user->ID);
        
        // Delete reset token
        delete_user_meta($user->ID, 'n1_reset_token');
        delete_user_meta($user->ID, 'n1_reset_token_expiry');
        
        // Generate new API token
        $api_token = $this->generate_token($user->ID);
        
        return rest_ensure_response(array(
            'message' => 'Senha redefinida com sucesso',
            'data' => array(
                'user' => $this->format_user($user),
                'token' => $api_token,
            ),
        ));
    }
    
    /**
     * Change password
     */
    public function change_password($request) {
        $params = $request->get_json_params();
        
        $current_password = isset($params['currentPassword']) ? $params['currentPassword'] : '';
        $new_password = isset($params['newPassword']) ? $params['newPassword'] : '';
        
        $user_id = get_current_user_id();
        
        if (!$user_id) {
            return new WP_Error('not_authenticated', 'Usuário não autenticado', array('status' => 401));
        }
        
        if (empty($current_password) || empty($new_password)) {
            return new WP_Error('missing_fields', 'Senha atual e nova senha são obrigatórias', array('status' => 400));
        }
        
        // Verify current password
        $user = get_userdata($user_id);
        if (!wp_check_password($current_password, $user->user_pass, $user_id)) {
            return new WP_Error('invalid_password', 'Senha atual incorreta', array('status' => 400));
        }
        
        // Update password
        wp_set_password($new_password, $user_id);
        
        // Generate new token
        $token = $this->generate_token($user_id);
        
        return rest_ensure_response(array(
            'message' => 'Senha alterada com sucesso',
            'data' => array(
                'user' => $this->format_user($user),
                'token' => $token,
            ),
        ));
    }
    
    /**
     * Update user profile
     */
    public function update_user($request) {
        $user_id = intval($request['id']);
        $current_user_id = get_current_user_id();
        
        // Check if user can update this profile
        if ($user_id !== $current_user_id && !current_user_can('edit_users')) {
            return new WP_Error('permission_denied', 'Você não tem permissão para atualizar este perfil', array('status' => 403));
        }
        
        $params = $request->get_json_params();
        
        $update_data = array('ID' => $user_id);
        
        if (isset($params['name'])) {
            $update_data['display_name'] = sanitize_text_field($params['name']);
        }
        
        if (isset($params['email'])) {
            $email = sanitize_email($params['email']);
            if (is_email($email)) {
                // Check if email is already used by another user
                $existing_user = get_user_by('email', $email);
                if ($existing_user && $existing_user->ID !== $user_id) {
                    return new WP_Error('email_exists', 'Este e-mail já está em uso', array('status' => 409));
                }
                $update_data['user_email'] = $email;
            }
        }
        
        $result = wp_update_user($update_data);
        
        if (is_wp_error($result)) {
            return new WP_Error('update_failed', $result->get_error_message(), array('status' => 500));
        }
        
        $user = get_userdata($user_id);
        $token = $this->generate_token($user_id);
        
        return rest_ensure_response(array(
            'message' => 'Perfil atualizado com sucesso',
            'data' => array(
                'user' => $this->format_user($user),
                'token' => $token,
            ),
        ));
    }
    
    /**
     * Confirm email
     */
    public function confirm_email($request) {
        $token = sanitize_text_field($request['token']);
        
        // Find user by confirmation token
        $users = get_users(array(
            'meta_key' => 'n1_email_confirmation_token',
            'meta_value' => $token,
            'number' => 1,
        ));
        
        if (empty($users)) {
            return new WP_Error('invalid_token', 'Token de confirmação inválido', array('status' => 400));
        }
        
        $user = $users[0];
        
        // Mark email as confirmed
        update_user_meta($user->ID, 'n1_email_confirmed', true);
        delete_user_meta($user->ID, 'n1_email_confirmation_token');
        
        // Generate API token
        $api_token = $this->generate_token($user->ID);
        
        return rest_ensure_response(array(
            'message' => 'E-mail confirmado com sucesso',
            'data' => array(
                'user' => $this->format_user($user),
                'token' => $api_token,
            ),
        ));
    }
    
    /**
     * Create Payment Intent (Stripe)
     */
    public function create_payment_intent($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce não está ativo', array('status' => 500));
        }
        
        $params = $request->get_json_params();
        $amount = isset($params['price']) ? floatval($params['price']) : 0;
        
        if ($amount <= 0) {
            return new WP_Error('invalid_amount', 'Valor inválido', array('status' => 400));
        }
        
        // Converter para centavos (Stripe usa centavos)
        $amount_in_cents = intval($amount * 100);
        
        // Verificar se a biblioteca Stripe está disponível
        if (!function_exists('curl_init')) {
            return new WP_Error('stripe_unavailable', 'Stripe não está disponível', array('status' => 500));
        }
        
        // Criar Payment Intent via API do Stripe
        $stripe_url = 'https://api.stripe.com/v1/payment_intents';
        $stripe_data = array(
            'amount' => $amount_in_cents,
            'currency' => 'brl', // BRL para reais brasileiros
            'payment_method_types[]' => 'card',
        );
        
        $ch = curl_init($stripe_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($stripe_data));
        curl_setopt($ch, CURLOPT_USERPWD, $this->stripe_secret_key . ':');
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/x-www-form-urlencoded',
        ));
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code !== 200) {
            $error_data = json_decode($response, true);
            return new WP_Error('stripe_error', isset($error_data['error']['message']) ? $error_data['error']['message'] : 'Erro ao criar Payment Intent', array('status' => $http_code));
        }
        
        $payment_intent = json_decode($response, true);
        
        if (!isset($payment_intent['client_secret'])) {
            return new WP_Error('stripe_error', 'Resposta inválida do Stripe', array('status' => 500));
        }
        
        return rest_ensure_response(array(
            'clientSecret' => $payment_intent['client_secret'],
            'paymentIntentId' => $payment_intent['id'],
        ));
    }
    
    /**
     * Add Order (WooCommerce)
     */
    public function add_order($request) {
        try {
            if (!class_exists('WooCommerce')) {
                return new WP_Error('woocommerce_not_active', 'WooCommerce não está ativo', array('status' => 500));
            }
            
            $params = $request->get_json_params();
            
            // Log para debug (remover em produção)
            error_log('N1 API - add_order chamado com: ' . print_r($params, true));
        
        // Validar dados obrigatórios - o frontend pode enviar 'cart' ou 'cart_products'
        $cart_products = isset($params['cart']) ? $params['cart'] : (isset($params['cart_products']) ? $params['cart_products'] : array());
        
        if (!is_array($cart_products) || empty($cart_products)) {
            return new WP_Error('invalid_data', 'Produtos do carrinho são obrigatórios', array('status' => 400));
        }
        
        // O frontend pode enviar shipping_info ou os dados diretamente
        $shipping_info = isset($params['shipping_info']) ? $params['shipping_info'] : array();
        
        if (empty($shipping_info) && isset($params['name'])) {
            // Se não houver shipping_info, tentar construir a partir dos dados diretos
            $name_parts = explode(' ', $params['name'], 2);
            $shipping_info = array(
                'firstName' => isset($name_parts[0]) ? $name_parts[0] : '',
                'lastName' => isset($name_parts[1]) ? $name_parts[1] : '',
                'email' => isset($params['email']) ? $params['email'] : '',
                'phone' => isset($params['contact']) ? $params['contact'] : '',
                'address' => isset($params['address']) ? $params['address'] : '',
                'city' => isset($params['city']) ? $params['city'] : '',
                'country' => isset($params['country']) ? $params['country'] : 'BR',
                'postcode' => isset($params['zipCode']) ? $params['zipCode'] : '',
            );
        }
        
        if (empty($shipping_info)) {
            return new WP_Error('invalid_data', 'Informações de entrega são obrigatórias', array('status' => 400));
        }
        
        $user_id = get_current_user_id();
        if (!$user_id) {
            return new WP_Error('unauthorized', 'Usuário não autenticado', array('status' => 401));
        }
        
        $coupon_info = isset($params['couponInfo']) ? $params['couponInfo'] : null;
        
        // Extrair payment intent ID - pode vir como objeto ou string
        $payment_intent_id = null;
        $payment_status = 'succeeded'; // Default para succeeded se houver paymentIntent
        
        if (isset($params['paymentIntent'])) {
            if (is_array($params['paymentIntent']) || is_object($params['paymentIntent'])) {
                $payment_intent_obj = is_array($params['paymentIntent']) ? $params['paymentIntent'] : (array)$params['paymentIntent'];
                $payment_intent_id = isset($payment_intent_obj['id']) ? sanitize_text_field($payment_intent_obj['id']) : null;
                $payment_status = isset($payment_intent_obj['status']) ? sanitize_text_field($payment_intent_obj['status']) : 'succeeded';
            } else {
                $payment_intent_id = sanitize_text_field($params['paymentIntent']);
            }
        }
        
        if (isset($params['paymentStatus'])) {
            $payment_status = sanitize_text_field($params['paymentStatus']);
        }
        
        // Se não houver paymentIntent, considerar como pending
        if (!$payment_intent_id) {
            $payment_status = 'pending';
        }
        
        // Calcular total
        $subtotal = 0;
        $line_items = array();
        
        foreach ($cart_products as $item) {
            $product_id = isset($item['_id']) ? intval($item['_id']) : (isset($item['id']) ? intval($item['id']) : 0);
            $quantity = isset($item['orderQuantity']) ? intval($item['orderQuantity']) : 1;
            $price = isset($item['price']) ? floatval($item['price']) : 0;
            
            if ($product_id > 0) {
                $product = wc_get_product($product_id);
                if ($product) {
                    $line_items[] = array(
                        'product_id' => $product_id,
                        'quantity' => $quantity,
                        'subtotal' => $price * $quantity,
                        'total' => $price * $quantity,
                    );
                    $subtotal += $price * $quantity;
                }
            }
        }
        
        // Aplicar desconto do cupom se houver
        $discount_total = 0;
        if ($coupon_info && isset($coupon_info['discountValue'])) {
            $discount_total = floatval($coupon_info['discountValue']);
        }
        
        $total = $subtotal - $discount_total;
        if ($total < 0) {
            $total = 0;
        }
        
        // Criar pedido no WooCommerce
        $order = wc_create_order();
        
        if (is_wp_error($order)) {
            return new WP_Error('order_creation_failed', 'Erro ao criar pedido: ' . $order->get_error_message(), array('status' => 500));
        }
        
        // Adicionar produtos ao pedido
        foreach ($line_items as $line_item) {
            $product = wc_get_product($line_item['product_id']);
            if ($product) {
                $order->add_product($product, $line_item['quantity']);
            }
        }
        
        // Aplicar cupom se houver
        if ($coupon_info && isset($coupon_info['couponCode'])) {
            $coupon_code = sanitize_text_field($coupon_info['couponCode']);
            $order->apply_coupon($coupon_code);
        }
        
        // Adicionar informações de entrega
        $billing_address = array(
            'first_name' => isset($shipping_info['firstName']) ? sanitize_text_field($shipping_info['firstName']) : '',
            'last_name' => isset($shipping_info['lastName']) ? sanitize_text_field($shipping_info['lastName']) : '',
            'email' => isset($shipping_info['email']) ? sanitize_email($shipping_info['email']) : '',
            'phone' => isset($shipping_info['phone']) ? sanitize_text_field($shipping_info['phone']) : (isset($shipping_info['contact']) ? sanitize_text_field($shipping_info['contact']) : ''),
            'address_1' => isset($shipping_info['address']) ? sanitize_text_field($shipping_info['address']) : '',
            'city' => isset($shipping_info['city']) ? sanitize_text_field($shipping_info['city']) : '',
            'state' => isset($shipping_info['state']) ? sanitize_text_field($shipping_info['state']) : '',
            'postcode' => isset($shipping_info['postcode']) ? sanitize_text_field($shipping_info['postcode']) : (isset($shipping_info['zipCode']) ? sanitize_text_field($shipping_info['zipCode']) : ''),
            'country' => isset($shipping_info['country']) ? sanitize_text_field($shipping_info['country']) : 'BR',
        );
        
        $shipping_address = $billing_address;
        
        $order->set_billing_address($billing_address);
        $order->set_shipping_address($shipping_address);
        
        // Definir método de pagamento
        $order->set_payment_method('stripe');
        $order->set_payment_method_title('Cartão de Crédito (Stripe)');
        
        // Adicionar meta do payment intent se houver
        if ($payment_intent_id) {
            $order->update_meta_data('_stripe_payment_intent_id', $payment_intent_id);
        }
        
        // Definir status do pagamento
        if ($payment_status === 'succeeded' || $payment_status === 'paid') {
            $order->set_status('processing');
        } else {
            $order->set_status('pending');
        }
        
        // Calcular totais
        $order->calculate_totals();
        
        // Associar pedido ao usuário
        $order->set_customer_id($user_id);
        
        // Garantir que o usuário está definido como atual
        wp_set_current_user($user_id);
        
        // Salvar pedido
        $order_id = $order->save();
        
        if (!$order_id || is_wp_error($order_id)) {
            $error_msg = is_wp_error($order_id) ? $order_id->get_error_message() : 'Erro desconhecido ao salvar pedido';
            error_log('N1 API - Erro ao salvar pedido: ' . $error_msg);
            return new WP_Error('order_save_failed', 'Erro ao salvar pedido: ' . $error_msg, array('status' => 500));
        }
        
        // Recarregar o pedido para garantir que os dados estão atualizados
        $saved_order = wc_get_order($order_id);
        if ($saved_order) {
            // Verificar e corrigir customer_id se necessário
            $saved_customer_id = $saved_order->get_customer_id();
            if ($saved_customer_id != $user_id) {
                error_log('N1 API - Customer ID incorreto. Corrigindo de ' . $saved_customer_id . ' para ' . $user_id);
                $saved_order->set_customer_id($user_id);
                $saved_order->save();
            }
            error_log('N1 API - Pedido criado com sucesso. ID: ' . $order_id . ', Customer ID: ' . $saved_order->get_customer_id());
        } else {
            error_log('N1 API - Pedido criado mas não foi possível recarregar. ID: ' . $order_id);
        }
        
        return rest_ensure_response(array(
            'success' => true,
            'message' => 'Pedido criado com sucesso',
            'order' => array(
                '_id' => (string)$order_id,
                'id' => $order_id,
                'order_number' => $order->get_order_number(),
                'status' => $order->get_status(),
                'total' => $order->get_total(),
                'date_created' => $order->get_date_created()->date('Y-m-d H:i:s'),
            ),
        ));
        } catch (Exception $e) {
            error_log('N1 API - Exceção em add_order: ' . $e->getMessage());
            error_log('N1 API - Stack trace: ' . $e->getTraceAsString());
            return new WP_Error('server_error', 'Erro ao processar pedido: ' . $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Get all orders by user
     */
    public function get_user_orders($request) {
        try {
            if (!class_exists('WooCommerce')) {
                return new WP_Error('woocommerce_not_active', 'WooCommerce não está ativo', array('status' => 500));
            }
            
            // O permission_callback já verificou a autenticação, mas vamos garantir que o usuário está definido
            $user_id = get_current_user_id();
            if (!$user_id) {
                error_log('N1 API - get_user_orders: get_current_user_id retornou 0. Tentando reautenticar...');
                // Tentar reautenticar se necessário
                $auth_result = $this->check_authentication();
                if (is_wp_error($auth_result)) {
                    error_log('N1 API - get_user_orders: Erro na reautenticação: ' . $auth_result->get_error_message());
                    return $auth_result;
                }
                $user_id = get_current_user_id();
                if (!$user_id) {
                    error_log('N1 API - get_user_orders: get_current_user_id ainda retorna 0 após reautenticação');
                    return new WP_Error('unauthorized', 'Usuário não autenticado', array('status' => 401));
                }
            }
            
            error_log('N1 API - get_user_orders: Buscando pedidos para usuário ID: ' . $user_id);
            
            $orders = wc_get_orders(array(
                'customer_id' => $user_id,
                'limit' => -1,
                'orderby' => 'date',
                'order' => 'DESC',
            ));
            
            $formatted_orders = array();
            $total_doc = 0;
            $pending = 0;
            $processing = 0;
            $delivered = 0;
            
            if (is_array($orders)) {
                foreach ($orders as $order) {
                    try {
                        $formatted_order = $this->format_order($order);
                        if ($formatted_order) {
                            $formatted_orders[] = $formatted_order;
                            $total_doc++;
                            
                            // Contar por status
                            $status = $order->get_status();
                            if ($status === 'pending' || $status === 'on-hold') {
                                $pending++;
                            } elseif ($status === 'processing') {
                                $processing++;
                            } elseif ($status === 'completed' || $status === 'delivered') {
                                $delivered++;
                            }
                        }
                    } catch (Exception $e) {
                        // Continuar processando outros pedidos mesmo se um falhar
                        error_log('Erro ao formatar pedido: ' . $e->getMessage());
                        continue;
                    }
                }
            }
            
            return rest_ensure_response(array(
                'orders' => $formatted_orders,
                'totalDoc' => $total_doc,
                'pending' => $pending,
                'processing' => $processing,
                'delivered' => $delivered,
            ));
        } catch (Exception $e) {
            error_log('N1 API - Exceção em get_user_orders: ' . $e->getMessage());
            error_log('N1 API - Stack trace: ' . $e->getTraceAsString());
            return new WP_Error('server_error', 'Erro ao buscar pedidos: ' . $e->getMessage(), array('status' => 500));
        } catch (Error $e) {
            error_log('N1 API - Erro fatal em get_user_orders: ' . $e->getMessage());
            error_log('N1 API - Stack trace: ' . $e->getTraceAsString());
            return new WP_Error('server_error', 'Erro fatal ao buscar pedidos: ' . $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Get single order by ID
     */
    public function get_single_order($request) {
        try {
            if (!class_exists('WooCommerce')) {
                return new WP_Error('woocommerce_not_active', 'WooCommerce não está ativo', array('status' => 500));
            }
            
            $order_id = intval($request['id']);
            error_log('N1 API - Buscando pedido ID: ' . $order_id);
            
            // O permission_callback já verificou a autenticação, mas vamos garantir que o usuário está definido
            $user_id = get_current_user_id();
            
            if (!$user_id) {
                error_log('N1 API - get_single_order: get_current_user_id retornou 0. Tentando reautenticar...');
                // Tentar reautenticar se necessário
                $auth_result = $this->check_authentication();
                if (is_wp_error($auth_result)) {
                    error_log('N1 API - get_single_order: Erro na reautenticação: ' . $auth_result->get_error_message());
                    return $auth_result;
                }
                $user_id = get_current_user_id();
                if (!$user_id) {
                    error_log('N1 API - get_single_order: get_current_user_id ainda retorna 0 após reautenticação');
                    return new WP_Error('unauthorized', 'Usuário não autenticado', array('status' => 401));
                }
            }
            
            error_log('N1 API - Usuário autenticado ID: ' . $user_id);
            
            $order = wc_get_order($order_id);
            
            if (!$order) {
                error_log('N1 API - Pedido não encontrado: ' . $order_id);
                return new WP_Error('order_not_found', 'Pedido não encontrado', array('status' => 404));
            }
            
            $customer_id = $order->get_customer_id();
            error_log('N1 API - Pedido encontrado. Customer ID: ' . $customer_id . ', User ID: ' . $user_id);
            
            // Verificar se o pedido pertence ao usuário
            // Se customer_id for 0 ou vazio, pode ser um pedido criado sem usuário - permitir se for admin
            if ($customer_id != $user_id) {
                // Verificar se é admin ou se pode editar pedidos
                if (!current_user_can('edit_shop_orders')) {
                    // Verificar também pelo email de cobrança como fallback
                    $billing_email = $order->get_billing_email();
                    $user_email = get_userdata($user_id)->user_email;
                    
                    if ($billing_email != $user_email) {
                        error_log('N1 API - Permissão negada. Customer: ' . $customer_id . ', User: ' . $user_id . ', Email billing: ' . $billing_email . ', User email: ' . $user_email);
                        return new WP_Error('permission_denied', 'Você não tem permissão para visualizar este pedido', array('status' => 403));
                    } else {
                        error_log('N1 API - Permissão concedida por email. Customer: ' . $customer_id . ', User: ' . $user_id);
                    }
                } else {
                    error_log('N1 API - Permissão concedida (admin). Customer: ' . $customer_id . ', User: ' . $user_id);
                }
            } else {
                error_log('N1 API - Permissão concedida (customer_id match). Customer: ' . $customer_id . ', User: ' . $user_id);
            }
            
            error_log('N1 API - Formatando pedido...');
            $formatted_order = $this->format_order($order);
            
            if (!$formatted_order) {
                error_log('N1 API - Erro ao formatar pedido');
                return new WP_Error('order_format_error', 'Erro ao formatar pedido', array('status' => 500));
            }
            
            error_log('N1 API - Pedido formatado com sucesso');
            return rest_ensure_response(array(
                'order' => $formatted_order,
            ));
        } catch (Exception $e) {
            error_log('N1 API - Exceção em get_single_order: ' . $e->getMessage());
            error_log('N1 API - Stack trace: ' . $e->getTraceAsString());
            return new WP_Error('server_error', 'Erro ao buscar pedido: ' . $e->getMessage(), array('status' => 500));
        } catch (Error $e) {
            error_log('N1 API - Erro fatal em get_single_order: ' . $e->getMessage());
            error_log('N1 API - Stack trace: ' . $e->getTraceAsString());
            return new WP_Error('server_error', 'Erro fatal ao buscar pedido: ' . $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Format order data for API response
     */
    private function format_order($order) {
        try {
            if (!$order || !is_a($order, 'WC_Order')) {
                error_log('N1 API - format_order: Pedido inválido ou não é WC_Order');
                return null;
            }
            
            error_log('N1 API - format_order: Iniciando formatação do pedido ID: ' . $order->get_id());
            
            // Obter itens do pedido
            $cart_items = array();
            $items = $order->get_items();
            if (is_array($items)) {
                foreach ($items as $item_id => $item) {
                    try {
                        $product = $item->get_product();
                        $product_id = $product ? $product->get_id() : 0;
                        
                        $quantity = $item->get_quantity();
                        $quantity = $quantity > 0 ? $quantity : 1;
                        
                        $item_price = floatval($item->get_total() / $quantity);
                        $regular_price = $product ? floatval($product->get_regular_price()) : $item_price;
                        $sale_price = $product ? ($product->get_sale_price() ? floatval($product->get_sale_price()) : $regular_price) : $item_price;
                        $discount = 0;
                        
                        if ($regular_price > 0 && $sale_price < $regular_price) {
                            $discount = round((($regular_price - $sale_price) / $regular_price) * 100);
                        }
                        
                        $image_url = wc_placeholder_img_src();
                        if ($product && $product->get_image_id()) {
                            $image_url = wp_get_attachment_image_url($product->get_image_id(), 'large');
                            if (!$image_url) {
                                $image_url = wc_placeholder_img_src();
                            }
                        }
                        
                        $cart_items[] = array(
                            '_id' => (string)$product_id,
                            'id' => $product_id,
                            'title' => $item->get_name() ? $item->get_name() : 'Produto',
                            'price' => $sale_price,
                            'originalPrice' => $regular_price,
                            'discount' => $discount,
                            'orderQuantity' => $quantity,
                            'image' => $image_url,
                        );
                    } catch (Exception $e) {
                        error_log('Erro ao formatar item do pedido: ' . $e->getMessage());
                        continue;
                    }
                }
            }
            
            // Obter informações de cobrança de forma segura
            $billing = array();
            try {
                $billing_data = $order->get_billing();
                if (is_array($billing_data)) {
                    $billing = $billing_data;
                } else {
                    // Se não for array, obter campos individualmente
                    $billing = array(
                        'first_name' => $order->get_billing_first_name(),
                        'last_name' => $order->get_billing_last_name(),
                        'email' => $order->get_billing_email(),
                        'phone' => $order->get_billing_phone(),
                        'address_1' => $order->get_billing_address_1(),
                        'address_2' => $order->get_billing_address_2(),
                        'city' => $order->get_billing_city(),
                        'state' => $order->get_billing_state(),
                        'postcode' => $order->get_billing_postcode(),
                        'country' => $order->get_billing_country(),
                    );
                }
            } catch (Exception $e) {
                error_log('Erro ao obter dados de cobrança: ' . $e->getMessage());
                // Usar métodos individuais como fallback
                $billing = array(
                    'first_name' => method_exists($order, 'get_billing_first_name') ? $order->get_billing_first_name() : '',
                    'last_name' => method_exists($order, 'get_billing_last_name') ? $order->get_billing_last_name() : '',
                    'email' => method_exists($order, 'get_billing_email') ? $order->get_billing_email() : '',
                    'phone' => method_exists($order, 'get_billing_phone') ? $order->get_billing_phone() : '',
                    'address_1' => method_exists($order, 'get_billing_address_1') ? $order->get_billing_address_1() : '',
                    'city' => method_exists($order, 'get_billing_city') ? $order->get_billing_city() : '',
                    'postcode' => method_exists($order, 'get_billing_postcode') ? $order->get_billing_postcode() : '',
                    'country' => method_exists($order, 'get_billing_country') ? $order->get_billing_country() : 'BR',
                );
            }
            
            // Formatar data
            $date_created = $order->get_date_created();
            $created_at = '';
            if ($date_created) {
                try {
                    $created_at = $date_created->date('Y-m-d H:i:s');
                } catch (Exception $e) {
                    $created_at = date('Y-m-d H:i:s');
                }
            } else {
                $created_at = date('Y-m-d H:i:s');
            }
            
            // Obter informações do pagamento
            $payment_method = $order->get_payment_method();
            $payment_method_title = $order->get_payment_method_title();
            
            // Obter cupons aplicados
            $coupons = $order->get_coupon_codes();
            $coupon_info = null;
            if (!empty($coupons) && is_array($coupons)) {
                try {
                    $coupon_code = $coupons[0];
                    $coupon = new WC_Coupon($coupon_code);
                    if ($coupon && $coupon->get_id()) {
                        $coupon_info = array(
                            'couponCode' => $coupon_code,
                            'discountValue' => floatval($order->get_total_discount()),
                        );
                    }
                } catch (Exception $e) {
                    error_log('Erro ao processar cupom: ' . $e->getMessage());
                }
            }
            
            $formatted = array(
                '_id' => (string)$order->get_id(),
                'id' => $order->get_id(),
                'invoice' => $order->get_order_number(),
                'name' => trim((isset($billing['first_name']) ? $billing['first_name'] : '') . ' ' . (isset($billing['last_name']) ? $billing['last_name'] : '')),
                'email' => isset($billing['email']) ? $billing['email'] : '',
                'contact' => isset($billing['phone']) ? $billing['phone'] : '',
                'country' => isset($billing['country']) ? $billing['country'] : 'BR',
                'city' => isset($billing['city']) ? $billing['city'] : '',
                'address' => isset($billing['address_1']) ? $billing['address_1'] : '',
                'zipCode' => isset($billing['postcode']) ? $billing['postcode'] : '',
                'cart' => $cart_items,
                'shippingCost' => floatval($order->get_shipping_total()),
                'discount' => floatval($order->get_total_discount()),
                'totalAmount' => floatval($order->get_total()),
                'subTotal' => floatval($order->get_subtotal()),
                'status' => $order->get_status(),
                'paymentMethod' => $payment_method ? $payment_method : 'stripe',
                'paymentMethodTitle' => $payment_method_title ? $payment_method_title : 'Cartão de Crédito',
                'createdAt' => $created_at,
                'cardInfo' => array(
                    'type' => $payment_method ? $payment_method : 'stripe',
                    'last4' => $order->get_meta('_stripe_source_id') ? substr($order->get_meta('_stripe_source_id'), -4) : '',
                ),
                'couponInfo' => $coupon_info,
            );
            
            error_log('N1 API - format_order: Pedido formatado com sucesso. ID: ' . $order->get_id());
            return $formatted;
        } catch (Exception $e) {
            error_log('N1 API - Exceção em format_order: ' . $e->getMessage());
            error_log('N1 API - Stack trace: ' . $e->getTraceAsString());
            return null;
        }
    }
}

// Initialize plugin
new N1_WooCommerce_API();

